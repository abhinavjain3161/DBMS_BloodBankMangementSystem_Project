const express = require('express')
const mysql = require('mysql')
const cors = require('cors')

const app = express()

app.use(cors())
app.use(express.json())

const db = mysql.createConnection({
host:'localhost',
user:'root',
password:'passw)123',
database:'bloodbank'
})

db.connect(err=>{
if(err){
console.log(err)
}else{
console.log("MySQL Connected")
}
})

/* GET DONORS */

app.get('/donors',(req,res)=>{

db.query("SELECT * FROM Donor",(err,result)=>{
if(err) res.send(err)
else res.send(result)
})

})

/* ADD DONOR */

app.post('/donor',(req,res)=>{

const donor=req.body

db.query(
"INSERT INTO Donor(name,age,gender,blood_group,phone,address) VALUES (?,?,?,?,?,?)",
[
donor.name,
donor.age,
donor.gender,
donor.blood_group,
donor.phone,
donor.address
],
(err,result)=>{

if(err){
res.send(err)
}else{

const donorId = result.insertId

db.query(
"INSERT INTO Blood_Unit(bloodGroup,volume,collectionDate,expiryDate,donor_id,bank_id,status) VALUES (?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 60 DAY),?,?,?)",
[
donor.blood_group,
450,
donorId,
1,
"Available"
]
)

res.send("Donor Registered and Blood Stored")

}

})

})

/* GET RECIPIENT REQUESTS */

app.get('/recipients',(req,res)=>{

db.query("SELECT * FROM Recipient",(err,result)=>{
if(err) res.send(err)
else res.send(result)
})

})

/* ADD RECIPIENT REQUEST */

app.post('/recipient',(req,res)=>{

const rec=req.body

db.query(
"INSERT INTO Recipient(name,blood_group,hospital_name,phone) VALUES (?,?,?,?)",
[
rec.name,
rec.blood_group,
rec.hospital_name,
rec.phone
],
(err,result)=>{
if(err) res.send(err)
else res.send("Request Submitted")
})

})

/* SEARCH BLOOD */

app.get('/blood/:group',(req,res)=>{

const group=req.params.group

db.query(
"SELECT * FROM Blood_Unit WHERE bloodGroup=? AND status='Available'",
[group],
(err,result)=>{
if(err) res.send(err)
else res.send(result)
})

})

/* ALL BLOOD UNITS */

app.get('/bloodunits',(req,res)=>{

db.query("SELECT * FROM Blood_Unit",(err,result)=>{
if(err) res.send(err)
else res.send(result)
})

})

/* AVAILABLE BLOOD UNITS */

app.get('/bloodavailable',(req,res)=>{

db.query(
"SELECT * FROM Blood_Unit WHERE status='Available'",
(err,result)=>{
if(err) res.send(err)
else res.send(result)
})

})

/* ISSUE BLOOD */

app.post('/issueblood',(req,res)=>{

const {recipient_id,unitNo}=req.body

db.query(
"INSERT INTO Receives VALUES (?,?,CURDATE())",
[recipient_id,unitNo],
(err,result)=>{

if(err){
res.send(err)
}else{

db.query(
"UPDATE Blood_Unit SET status='Issued' WHERE unitNo=?",
[unitNo]
)

res.send("Blood Issued Successfully")

}

})

})

app.get('/bloodunits',(req,res)=>{

db.query("SELECT * FROM Blood_Unit",(err,result)=>{

if(err){
res.send(err)
}else{
res.send(result)
}

})

})

app.listen(3000,()=>{
console.log("Server running on port 3000")
})