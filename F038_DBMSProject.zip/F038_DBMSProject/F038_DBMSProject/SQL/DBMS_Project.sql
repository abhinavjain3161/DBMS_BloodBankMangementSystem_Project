CREATE DATABASE bloodbank;
USE bloodbank;

CREATE TABLE Donor(
donor_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(50),
age INT,
gender VARCHAR(10),
blood_group VARCHAR(5),
phone VARCHAR(15),
address VARCHAR(100)
);

CREATE TABLE Blood_Bank(
bank_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(50),
location VARCHAR(100),
contact_no VARCHAR(15)
);

CREATE TABLE Staff(
staff_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(50),
role VARCHAR(50),
salary INT,
bank_id INT,
FOREIGN KEY (bank_id) REFERENCES Blood_Bank(bank_id)
);

CREATE TABLE Blood_Unit(
unitNo INT PRIMARY KEY AUTO_INCREMENT,
bloodGroup VARCHAR(5),
volume INT,
collectionDate DATE,
expiryDate DATE,
donor_id INT,
bank_id INT,
FOREIGN KEY (donor_id) REFERENCES Donor(donor_id),
FOREIGN KEY (bank_id) REFERENCES Blood_Bank(bank_id)
);

CREATE TABLE Recipient(
recipient_id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(50),
blood_group VARCHAR(5),
hospital_name VARCHAR(100),
phone VARCHAR(15)
);

CREATE TABLE Receives(
recipient_id INT,
unitNo INT,
issue_date DATE,
PRIMARY KEY(recipient_id,unitNo),
FOREIGN KEY(recipient_id) REFERENCES Recipient(recipient_id),
FOREIGN KEY(unitNo) REFERENCES Blood_Unit(unitNo)
);

INSERT INTO Donor(name,age,gender,blood_group,phone,address)
VALUES
('Dikshita Bansal',19,'Female','O+','9039377750','Indore'),
('Manasvi Sharma',19,'Female','B+','8827004489','Indore'),
('Abhinav Jain',20,'Male','O+','8109516404','Indore'),
('Priya Mehta',27,'Female','AB+','9876543213','Ahmedabad'),
('Aman Gupta',29,'Male','B+','9876543214','Delhi'),
('Sneha Kapoor',26,'Female','A-','9876543215','Pune'),
('Karan Shah',31,'Male','O-','9876543216','Mumbai'),
('Neha Jain',24,'Female','B-','9876543217','Indore'),
('Arjun Patel',33,'Male','A+','9876543218','Surat'),
('Riya Sharma',22,'Female','O+','9876543219','Bhopal');

INSERT INTO Blood_Bank VALUES
(1,'City Blood Bank','Delhi','0112345678'),
(2,'LifeCare Blood Bank','Mumbai','0222345678'),
(3,'Red Cross Blood Bank','Pune','0202345678');

INSERT INTO Staff VALUES
(1,'Suresh Kumar','Manager',50000,1),
(2,'Anita Singh','Technician',35000,1),
(3,'Rakesh Patel','Nurse',30000,2),
(4,'Sunita Shah','Manager',52000,2),
(5,'Arun Jain','Technician',34000,3);

INSERT INTO Blood_Unit VALUES
(101,'A+',450,'2026-01-10','2026-03-10',1,1),
(102,'O+',450,'2026-01-12','2026-03-12',2,1),
(103,'B+',450,'2026-01-15','2026-03-15',3,2),
(104,'AB+',450,'2026-01-18','2026-03-18',4,2),
(105,'O-',450,'2026-01-20','2026-03-20',5,3),
(106,'A-',450,'2026-01-22','2026-03-22',6,3),
(107,'B-',450,'2026-01-25','2026-03-25',7,1),
(108,'O+',450,'2026-01-28','2026-03-28',8,2),
(109,'A+',450,'2026-02-01','2026-04-01',9,3),
(110,'AB-',450,'2026-02-03','2026-04-03',10,1);

INSERT INTO Recipient VALUES
(1,'Arjun Kumar','A+','AIIMS Delhi','9876500001'),
(2,'Meera Joshi','O+','Apollo Hospital','9876500002'),
(3,'Ravi Singh','B+','Fortis Hospital','9876500003'),
(4,'Anita Shah','AB+','City Hospital','9876500004'),
(5,'Sanjay Gupta','O-','Medanta Hospital','9876500005');

INSERT INTO Receives VALUES
(1,101,'2026-03-01'),
(2,102,'2026-03-02'),
(3,103,'2026-03-03'),
(4,104,'2026-03-04'),
(5,105,'2026-03-05');

SELECT * FROM Blood_Bank;

SELECT * FROM Staff;

SELECT * FROM Blood_Unit;

SELECT * FROM Recipient;

SELECT * FROM Receives;

SELECT * FROM Donor;

INSERT INTO Blood_Bank VALUES
(4,'Metro Blood Bank','Chennai','0442345678'),
(5,'National Blood Bank','Hyderabad','0402345678'),
(6,'Central Blood Bank','Kolkata','0332345678'),
(7,'Apollo Blood Bank','Bangalore','0802345678'),
(8,'Fortis Blood Bank','Delhi','0119876543'),
(9,'Sunrise Blood Bank','Jaipur','0141234567'),
(10,'Hope Blood Bank','Lucknow','0522234567');

INSERT INTO Staff VALUES
(6,'Vikas Sharma','Nurse',32000,1),
(7,'Ritu Gupta','Technician',36000,2),
(8,'Amit Verma','Manager',55000,3),
(9,'Pooja Patel','Nurse',31000,1),
(10,'Deepak Singh','Technician',34000,2);

INSERT INTO Recipient VALUES
(6,'Rohan Kapoor','B+','Apollo Hospital','9876500006'),
(7,'Neha Verma','O+','Fortis Hospital','9876500007'),
(8,'Vikas Gupta','A-','AIIMS Delhi','9876500008'),
(9,'Pooja Singh','AB+','City Hospital','9876500009'),
(10,'Amit Sharma','B-','Medanta Hospital','9876500010');

INSERT INTO Receives VALUES
(6,106,'2026-03-06'),
(7,107,'2026-03-07'),
(8,108,'2026-03-08'),
(9,109,'2026-03-09'),
(10,110,'2026-03-10');

SELECT * FROM Blood_Bank;

SELECT * FROM Staff;

SELECT * FROM Recipient;

SELECT * FROM Receives;

SELECT name FROM Donor WHERE blood_group = 'O+';

SELECT COUNT(*) AS Total_Donors
FROM Donor;

SELECT *
FROM Staff
WHERE salary > 40000;

SELECT bank_id, COUNT(*) AS Total_Units
FROM Blood_Unit
GROUP BY bank_id;

SELECT Donor.name, Blood_Unit.unitNo
FROM Donor
JOIN Blood_Unit
ON Donor.donor_id = Blood_Unit.donor_id;

SELECT Recipient.name, Receives.issue_date
FROM Recipient
JOIN Receives
ON Recipient.recipient_id = Receives.recipient_id;

SELECT *
FROM Blood_Unit
WHERE expiryDate < '2026-04-01';

SELECT *
FROM Donor
ORDER BY age DESC;

SELECT bloodGroup, COUNT(*)
FROM Blood_Unit
GROUP BY bloodGroup;

SELECT *
FROM Blood_Unit;

SELECT Donor.name, Donor.blood_group, Blood_Unit.unitNo
FROM Donor
INNER JOIN Blood_Unit
ON Donor.donor_id = Blood_Unit.donor_id;

SELECT Recipient.name, Blood_Unit.bloodGroup, Receives.issue_date
FROM Recipient
INNER JOIN Receives
ON Recipient.recipient_id = Receives.recipient_id
INNER JOIN Blood_Unit
ON Receives.unitNo = Blood_Unit.unitNo;

SELECT Donor.name, Blood_Unit.unitNo
FROM Donor
LEFT JOIN Blood_Unit
ON Donor.donor_id = Blood_Unit.donor_id;

SELECT Donor.name, Blood_Unit.unitNo, Blood_Unit.bloodGroup
FROM Donor
RIGHT JOIN Blood_Unit
ON Donor.donor_id = Blood_Unit.donor_id;

SELECT Blood_Bank.name AS BloodBank, Staff.name AS Staff_Name
FROM Blood_Bank
LEFT JOIN Staff
ON Blood_Bank.bank_id = Staff.bank_id;

SELECT Donor.name, Blood_Unit.unitNo, Blood_Bank.name
FROM Donor
INNER JOIN Blood_Unit
ON Donor.donor_id = Blood_Unit.donor_id
INNER JOIN Blood_Bank
ON Blood_Unit.bank_id = Blood_Bank.bank_id;

SELECT Recipient.name, Receives.unitNo
FROM Recipient
LEFT JOIN Receives
ON Recipient.recipient_id = Receives.recipient_id;

SELECT Staff.name, Blood_Bank.name
FROM Staff
RIGHT JOIN Blood_Bank
ON Staff.bank_id = Blood_Bank.bank_id;

SELECT d1.name AS Donor1, d2.name AS Donor2, d1.blood_group
FROM Donor d1
JOIN Donor d2
ON d1.blood_group = d2.blood_group
AND d1.donor_id <> d2.donor_id;

ALTER USER 'root'@'localhost'
IDENTIFIED WITH mysql_native_password
BY 'passw)123';

FLUSH PRIVILEGES;

ALTER TABLE Blood_Unit
ADD status VARCHAR(20) DEFAULT 'Available';

UPDATE Blood_Unit SET status='Available';

UPDATE Blood_Unit 
SET status='Available'
WHERE unitNo > 0;

SELECT * FROM Blood_Unit;

SELECT * FROM Blood_Unit;